import React from 'react';
import './MonthlyExpenseReport.css';

function MonthlyExpenseReport({ 
  monthlyExpenses, 
  transactions, 
  salary,
  salaryChanges,
  currency = 'SAR',
  salaryVisible = true,
  toggleSalaryVisibility,
  openingBalance = 0,
  planStartDate
}) {
  // Helper function to check if expense applies to a specific month/year
  const isExpenseActiveInMonth = (expense, month, year) => {
    const startMonth = expense.start_month || 1;
    const endMonth = expense.end_month || 12;
    const startYear = expense.start_year || new Date().getFullYear();
    const endYear = expense.end_year || new Date().getFullYear();
    
    // Create date objects for comparison (using day 1 of each month)
    const checkDate = new Date(year, month - 1, 1);
    const expenseStartDate = new Date(startYear, startMonth - 1, 1);
    const expenseEndDate = new Date(endYear, endMonth - 1, 1);
    
    return checkDate >= expenseStartDate && checkDate <= expenseEndDate;
  };

  // Group expenses by month/year
  const groupExpensesByMonth = () => {
    const grouped = {};
    
    // Parse plan start date
    const startDate = planStartDate ? new Date(planStartDate) : new Date();
    const startYear = startDate.getFullYear();
    const startMonth = startDate.getMonth() + 1; // 1-12
    
    // Generate 12 months starting from plan start date
    for (let i = 0; i < 12; i++) {
      let currentMonth = startMonth + i;
      let currentYear = startYear;
      
      // Handle year wrap-around
      if (currentMonth > 12) {
        currentMonth = currentMonth - 12;
        currentYear = currentYear + 1;
      }
      
      const key = `${currentMonth}/${currentYear}`;
      grouped[key] = {
        date: key,
        expenses: [],
        dailyTransactions: []
      };
    }
    
    // Add recurring expenses for each month
    monthlyExpenses.forEach(expense => {
      // Check each of the 12 months
      for (let i = 0; i < 12; i++) {
        let currentMonth = startMonth + i;
        let currentYear = startYear;
        
        if (currentMonth > 12) {
          currentMonth = currentMonth - 12;
          currentYear = currentYear + 1;
        }
        
        const key = `${currentMonth}/${currentYear}`;
        
        // Check if this expense applies to this month/year
        if (isExpenseActiveInMonth(expense, currentMonth, currentYear)) {
          grouped[key].expenses.push({
            cashFor: expense.category || expense.description,
            amount: parseFloat(expense.amount) || 0,
            type: 'recurring'
          });
        }
      }
    });

    // Add daily transactions with full details
    transactions.forEach(trans => {
      if (trans.transaction_date) {
        const date = new Date(trans.transaction_date);
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        const key = `${month}/${year}`;
        
        if (grouped[key]) {
          grouped[key].dailyTransactions.push({
            date: trans.transaction_date,
            cashFor: trans.category || trans.description || 'Daily Transaction',
            amount: parseFloat(trans.amount) || 0,
            type: 'daily'
          });
        }
      }
    });

    // Convert to array and sort by date (already in order)
    return Object.values(grouped).sort((a, b) => {
      const [monthA, yearA] = a.date.split('/').map(Number);
      const [monthB, yearB] = b.date.split('/').map(Number);
      return yearA !== yearB ? yearA - yearB : monthA - monthB;
    });
  };

  const getSalaryForMonth = (dateStr) => {
    const numericSalary = parseFloat(salary) || 0;
    return numericSalary;
  };

  const formatSalary = (amount) => {
    return salaryVisible ? amount.toLocaleString() : '••••••';
  };

  // Calculate percentage of salary
  const calculatePercentage = (amount, salary) => {
    if (!salary || salary === 0) return 0;
    return ((amount / salary) * 100).toFixed(1);
  };

  // Get percentage color coding
  const getPercentageColor = (percentage) => {
    const pct = parseFloat(percentage);
    if (pct < 30) return '#2ecc71'; // green - low
    if (pct < 60) return '#3498db'; // blue - moderate
    if (pct < 80) return '#f39c12'; // yellow/orange - high
    return '#e74c3c'; // red - very high
  };

  const monthlyData = groupExpensesByMonth();

  // Calculate cumulative balance (carry forward from previous months)
  // Initialize with opening balance
  let cumulativeBalance = parseFloat(openingBalance) || 0;

  return (
    <div className="monthly-expense-report">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <div>
          <h2>📋 Detailed Monthly Expense Report</h2>
          <p className="report-subtitle">Excel-Style View with Daily Transaction Details & Balance Carry Forward</p>
        </div>
        {toggleSalaryVisibility && (
          <button 
            onClick={toggleSalaryVisibility}
            className="salary-toggle-btn"
            title={salaryVisible ? 'Hide Salary' : 'Show Salary'}
            style={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              border: 'none',
              borderRadius: '8px',
              padding: '10px 20px',
              cursor: 'pointer',
              fontSize: '1rem',
              fontWeight: 'bold',
              color: '#fff',
              boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)',
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
            onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
          >
            <span style={{ fontSize: '1.2rem' }}>{salaryVisible ? '🙈' : '👁️'}</span>
            <span>{salaryVisible ? 'Hide Salary' : 'Show Salary'}</span>
          </button>
        )}
      </div>

      {monthlyData.map((monthData, index) => {
        const currentSalary = getSalaryForMonth(monthData.date);
        const recurringTotal = monthData.expenses.reduce((sum, exp) => sum + exp.amount, 0);
        const dailyTotal = monthData.dailyTransactions.reduce((sum, trans) => sum + trans.amount, 0);
        const grandTotal = recurringTotal + dailyTotal;
        
        // Brought forward from previous month
        const broughtForward = cumulativeBalance;
        
        // Calculate remaining for this month
        const monthlyNet = currentSalary - grandTotal;
        const remaining = monthlyNet + broughtForward;
        
        // Update cumulative balance for next month
        cumulativeBalance = remaining;
        
        // Combine all items for display
        const allItems = [
          ...monthData.expenses,
          ...monthData.dailyTransactions
        ];
        
        const totalRows = allItems.length;

        return (
          <div key={index} className="month-report-section">
            <div className="table-responsive">
            <table className="excel-table">
              <thead>
                <tr className="header-row">
                  <th className="col-date">Date</th>
                  <th className="col-cashfor">Cash For</th>
                  <th className="col-amount">Amount ({currency})</th>
                  <th className="col-percentage">% من الراتب</th>
                  <th className="col-total">Total</th>
                  <th className="col-currency">Currency</th>
                  <th className="col-totals">Totals</th>
                </tr>
              </thead>
              <tbody>
                {/* Brought Forward row (if applicable) */}
                {broughtForward !== 0 && (
                  <tr className="brought-forward-row">
                    <td className="date-cell">{monthData.date}</td>
                    <td className="brought-forward-label" colSpan="2">
                      💼 Brought Forward (from previous month)
                    </td>
                    <td className="percentage-cell">-</td>
                    <td className="brought-forward-amount" colSpan="3">
                      <span className={broughtForward >= 0 ? 'positive' : 'negative'}>
                        {broughtForward >= 0 ? '+' : ''}{broughtForward.toLocaleString(undefined, { minimumFractionDigits: 1 })} {currency}
                      </span>
                    </td>
                  </tr>
                )}
                
                {/* First row with date */}
                {allItems.length > 0 ? (
                  <>
                    <tr>
                      <td className="date-cell" rowSpan={totalRows + (broughtForward !== 0 ? 0 : 1)}>
                        {broughtForward !== 0 ? '' : monthData.date}
                      </td>
                      <td className={`expense-name ${allItems[0].type === 'daily' ? 'daily-item' : ''}`}>
                        {allItems[0].type === 'daily' && (
                          <span className="daily-badge">Daily</span>
                        )}
                        {allItems[0].cashFor}
                      </td>
                      <td className="expense-amount">{allItems[0].amount.toLocaleString()}</td>
                      <td className="percentage-cell">
                        {salaryVisible && currentSalary > 0 && (
                          <span style={{ color: getPercentageColor(calculatePercentage(allItems[0].amount, currentSalary)), fontWeight: 'bold' }}>
                            {calculatePercentage(allItems[0].amount, currentSalary)}%
                          </span>
                        )}
                      </td>
                      <td className="total-cell" rowSpan={totalRows}>
                        {grandTotal.toLocaleString()}
                      </td>
                      <td className="currency-label">Salary</td>
                      <td className="salary-value">{formatSalary(currentSalary)}</td>
                    </tr>

                    {/* Remaining item rows */}
                    {allItems.slice(1).map((item, idx) => (
                      <tr key={idx}>
                        <td className={`expense-name ${item.type === 'daily' ? 'daily-item' : ''}`}>
                          {item.type === 'daily' && (
                            <span className="daily-badge">Daily</span>
                          )}
                          {item.cashFor}
                        </td>
                        <td className="expense-amount">{item.amount.toLocaleString()}</td>
                        <td className="percentage-cell">
                          {salaryVisible && currentSalary > 0 && (
                            <span style={{ color: getPercentageColor(calculatePercentage(item.amount, currentSalary)), fontWeight: 'bold' }}>
                              {calculatePercentage(item.amount, currentSalary)}%
                            </span>
                          )}
                        </td>
                        {idx === 0 && (
                          <>
                            <td className="currency-label">Monthly Net</td>
                            <td className={`remaining-value ${monthlyNet >= 0 ? 'positive' : 'negative'}`}>
                              {monthlyNet.toLocaleString(undefined, { minimumFractionDigits: 1 })}
                            </td>
                          </>
                        )}
                        {idx === 1 && broughtForward !== 0 && (
                          <>
                            <td className="currency-label">Brought Forward</td>
                            <td className={`remaining-value ${broughtForward >= 0 ? 'positive' : 'negative'}`}>
                              {broughtForward >= 0 ? '+' : ''}{broughtForward.toLocaleString(undefined, { minimumFractionDigits: 1 })}
                            </td>
                          </>
                        )}
                        {idx === (broughtForward !== 0 ? 2 : 1) && (
                          <>
                            <td className="currency-label final-balance-label">Final Balance</td>
                            <td className={`remaining-value final-balance ${remaining >= 0 ? 'positive' : 'negative'}`}>
                              {remaining.toLocaleString(undefined, { minimumFractionDigits: 1 })}
                            </td>
                          </>
                        )}
                        {(idx > (broughtForward !== 0 ? 2 : 1)) && (
                          <>
                            <td></td>
                            <td></td>
                          </>
                        )}
                      </tr>
                    ))}
                  </>
                ) : (
                  <tr>
                    <td className="date-cell">{monthData.date}</td>
                    <td className="expense-name">No expenses</td>
                    <td className="expense-amount">0</td>
                    <td className="percentage-cell">-</td>
                    <td className="total-cell">0</td>
                    <td className="currency-label">Salary</td>
                    <td className="salary-value">{formatSalary(currentSalary)}</td>
                  </tr>
                )}

                {/* Total Percentage Row */}
                <tr className="total-percentage-row">
                  <td colSpan="3" className="total-percentage-label">
                    📊 إجمالي النسبة من الراتب / Total % of Salary
                  </td>
                  <td className="total-percentage-value">
                    {salaryVisible && currentSalary > 0 ? (
                      <span style={{ 
                        color: getPercentageColor(calculatePercentage(grandTotal, currentSalary)), 
                        fontWeight: 'bold',
                        fontSize: '1.1rem'
                      }}>
                        {calculatePercentage(grandTotal, currentSalary)}%
                      </span>
                    ) : (
                      <span>-</span>
                    )}
                  </td>
                  <td colSpan="3" className="total-percentage-info">
                    {salaryVisible && currentSalary > 0 && (
                      <span className="percentage-breakdown">
                        {grandTotal.toLocaleString()} / {currentSalary.toLocaleString()} {currency}
                      </span>
                    )}
                  </td>
                </tr>

                {/* Grand total separator row */}
                <tr className="separator-row">
                  <td colSpan="7"></td>
                </tr>
              </tbody>
            </table>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default MonthlyExpenseReport;
