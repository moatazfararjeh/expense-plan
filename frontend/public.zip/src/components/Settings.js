import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../App.css';

const API_URL = process.env.REACT_APP_API_URL ? `${process.env.REACT_APP_API_URL}/api` : 'https://localhost:1001/api';

const Settings = ({ salary = 0, openingBalance = 0, planStartDate = '', onUpdateSettings, salaryChanges = [], onAddSalaryChange, onDeleteSalaryChange }) => {
  const [currency, setCurrency] = useState('SAR');
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState('');
  const [message, setMessage] = useState('');
  
  // Salary settings state
  const [salaryInput, setSalaryInput] = useState(salary);
  const [balanceInput, setBalanceInput] = useState(openingBalance);
  const [startDateInput, setStartDateInput] = useState(planStartDate || new Date().toISOString().split('T')[0]);
  
  // Salary changes state
  const [showSalaryChangeForm, setShowSalaryChangeForm] = useState(false);
  const [changeAmount, setChangeAmount] = useState('');
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [changeNotes, setChangeNotes] = useState('');

  useEffect(() => {
    fetchSettings();
    // Update local state when props change
    setSalaryInput(salary);
    setBalanceInput(openingBalance);
    setStartDateInput(planStartDate || new Date().toISOString().split('T')[0]);
  }, [salary, openingBalance, planStartDate]);

  const fetchSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/settings`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (response.data) {
        setCurrency(response.data.currency || 'SAR');
        setCategories(response.data.categories || ['Jordan Family Expense', 'Our Expense', 'Loan Sabb', 'Other']);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const saveSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      const settingsResponse = await axios.get(`${API_URL}/settings`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const currentSettings = settingsResponse.data;
      
      await axios.post(`${API_URL}/settings`, {
        ...currentSettings,
        currency,
        categories
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setMessage('Settings saved successfully!');
      setTimeout(() => setMessage(''), 3000);
      
      // Trigger a page reload to apply settings across all components
      window.location.reload();
    } catch (error) {
      console.error('Error saving settings:', error);
      setMessage('Error saving settings. Please try again.');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const addCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      setCategories([...categories, newCategory.trim()]);
      setNewCategory('');
    }
  };

  const removeCategory = (index) => {
    const updated = categories.filter((_, i) => i !== index);
    setCategories(updated);
  };

  const moveCategory = (index, direction) => {
    const newCategories = [...categories];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex >= 0 && targetIndex < newCategories.length) {
      [newCategories[index], newCategories[targetIndex]] = [newCategories[targetIndex], newCategories[index]];
      setCategories(newCategories);
    }
  };

  const handleSalaryUpdate = (e) => {
    e.preventDefault();
    if (salaryInput && salaryInput >= 0) {
      onUpdateSettings(parseFloat(salaryInput), parseFloat(balanceInput || 0), startDateInput);
      setMessage('Salary settings updated successfully!');
      setTimeout(() => setMessage(''), 3000);
    } else {
      setMessage('Error: Please enter a valid salary amount.');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handleAddSalaryChange = (e) => {
    e.preventDefault();
    if (changeAmount && changeAmount > 0 && effectiveDate) {
      onAddSalaryChange({ 
        amount: parseFloat(changeAmount), 
        effective_date: effectiveDate,
        notes: changeNotes 
      });
      setChangeAmount('');
      setEffectiveDate(new Date().toISOString().split('T')[0]);
      setChangeNotes('');
      setShowSalaryChangeForm(false);
      setMessage('Salary change added successfully!');
      setTimeout(() => setMessage(''), 3000);
    } else {
      setMessage('Error: Please enter a valid amount and date.');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="settings-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2>Settings</h2>
        <button 
          onClick={() => window.location.href = '/'}
          className="btn-home"
          style={{ 
            padding: '12px 24px',
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            cursor: 'pointer',
            fontSize: '1rem',
            fontWeight: '700',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            boxShadow: '0 4px 15px rgba(102, 126, 234, 0.4)',
            transform: 'translateY(0)',
            position: 'relative',
            overflow: 'hidden'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'translateY(-2px)';
            e.target.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.6)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'translateY(0)';
            e.target.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
          }}
          onMouseDown={(e) => {
            e.target.style.transform = 'translateY(0) scale(0.95)';
          }}
          onMouseUp={(e) => {
            e.target.style.transform = 'translateY(-2px) scale(1)';
          }}
        >
          <span style={{ fontSize: '1.2rem', animation: 'bounce 2s infinite' }}>🏠</span> 
          <span>Home</span>
        </button>
      </div>
      
      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-3px); }
        }
        
        .btn-home::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.3);
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .btn-home:active::before {
          width: 300px;
          height: 300px;
        }
      `}</style>
      
      {message && (
        <div className={`message ${message.includes('Error') ? 'error' : 'success'}`}>
          {message}
        </div>
      )}

      <div className="settings-section">
        <h3>💼 Salary & Plan Settings</h3>
        <p className="section-description">
          Configure your monthly salary, opening balance, and plan start date.
        </p>
        
        <form onSubmit={handleSalaryUpdate}>
          <div className="form-group">
            <label>Monthly Salary:</label>
            <input
              type="number"
              value={salaryInput}
              onChange={(e) => setSalaryInput(e.target.value)}
              placeholder="e.g., 30000"
              step="0.01"
              min="0"
            />
          </div>
          
          <div className="form-group">
            <label>Opening Balance (المبلغ الافتتاحي):</label>
            <input
              type="number"
              value={balanceInput}
              onChange={(e) => setBalanceInput(e.target.value)}
              placeholder="e.g., 5000"
              step="0.01"
              min="0"
            />
            <small className="help-text">
              المبلغ الموجود لديك قبل بدء الخطة (The amount you have before starting the plan)
            </small>
          </div>
          
          <div className="form-group">
            <label>Plan Start Date (تاريخ بداية الخطة):</label>
            <input
              type="date"
              value={startDateInput}
              onChange={(e) => setStartDateInput(e.target.value)}
            />
            <small className="help-text">
              تاريخ بدء تتبع المصروفات والمدخرات (Start date for tracking expenses and savings)
            </small>
          </div>
          
          <button type="submit" className="btn-add" style={{ marginTop: '10px' }}>
            Update Salary Settings
          </button>
        </form>

        {salary > 0 && (
          <div style={{ marginTop: '20px', padding: '15px', background: 'var(--gray-50)', borderRadius: 'var(--radius-lg)', border: '2px solid var(--primary-color)' }}>
            <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: 'var(--primary-color)' }}>
              Current Salary: {salary.toLocaleString()} {currency}
            </div>
            {openingBalance > 0 && (
              <div style={{ fontSize: '1rem', marginTop: '5px', color: 'var(--success-color)', fontWeight: '600' }}>
                Opening Balance: {openingBalance.toLocaleString()} {currency}
              </div>
            )}
            {planStartDate && (
              <div style={{ fontSize: '0.95rem', marginTop: '5px', color: 'var(--gray-600)', fontWeight: '600' }}>
                📅 Plan Start: {new Date(planStartDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="settings-section">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
          <h3>📈 Salary Changes (تغييرات الراتب)</h3>
          <button 
            onClick={() => setShowSalaryChangeForm(!showSalaryChangeForm)}
            className="btn btn-primary"
            style={{ padding: '8px 16px', fontSize: '0.9rem' }}
          >
            {showSalaryChangeForm ? 'Cancel' : '+ Add Change'}
          </button>
        </div>
        <p className="section-description">
          Track salary changes over time. These will be automatically applied in projections based on the effective date.
        </p>
        
        {showSalaryChangeForm && (
          <form onSubmit={handleAddSalaryChange} style={{ 
            padding: '15px', 
            background: 'var(--gray-50)', 
            borderRadius: 'var(--radius-lg)',
            marginBottom: '20px',
            border: '2px solid var(--primary-color)'
          }}>
            <div className="form-group">
              <label>New Salary Amount:</label>
              <input
                type="number"
                value={changeAmount}
                onChange={(e) => setChangeAmount(e.target.value)}
                placeholder="e.g., 35000"
                step="0.01"
                min="0"
              />
            </div>
            <div className="form-group">
              <label>Effective Date (تاريخ التطبيق):</label>
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Notes (Optional):</label>
              <input
                type="text"
                value={changeNotes}
                onChange={(e) => setChangeNotes(e.target.value)}
                placeholder="e.g., Annual raise, Promotion"
              />
            </div>
            <button type="submit" className="btn-add">
              Add Salary Change
            </button>
          </form>
        )}

        <div className="salary-changes-list">
          {salaryChanges.length > 0 ? (
            <>
              <div style={{ marginBottom: '10px', fontSize: '0.9rem', color: 'var(--gray-600)', fontWeight: '600' }}>
                {salaryChanges.length} salary change{salaryChanges.length !== 1 ? 's' : ''} recorded
              </div>
              {salaryChanges.map((change) => (
                <div key={change.id} style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '15px',
                  background: 'white',
                  border: '2px solid var(--gray-200)',
                  borderRadius: 'var(--radius-lg)',
                  marginBottom: '10px',
                  transition: 'all var(--transition-base)',
                  boxShadow: 'var(--shadow-sm)'
                }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '1.3rem', fontWeight: 'bold', color: 'var(--success-color)' }}>
                      {parseFloat(change.amount).toLocaleString()} {currency}
                    </div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--primary-color)', marginTop: '5px', fontWeight: '600' }}>
                      📅 Effective: {formatDate(change.effective_date)}
                    </div>
                    {change.notes && (
                      <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginTop: '5px', fontStyle: 'italic' }}>
                        {change.notes}
                      </div>
                    )}
                  </div>
                  <button 
                    className="btn-icon btn-delete"
                    onClick={() => onDeleteSalaryChange(change.id)}
                    style={{ marginLeft: '10px', padding: '8px 12px' }}
                  >
                    Delete
                  </button>
                </div>
              ))}
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '20px', color: 'var(--gray-400)', background: 'var(--gray-50)', borderRadius: 'var(--radius-lg)' }}>
              No salary changes recorded yet. Current salary will be used for all months.
            </div>
          )}
        </div>

        {salaryChanges.length > 0 && (
          <div style={{ 
            marginTop: '15px', 
            padding: '15px', 
            background: 'var(--info-light)', 
            borderRadius: 'var(--radius-lg)',
            fontSize: '0.9rem',
            color: 'var(--info-color)',
            border: '2px solid var(--info-color)'
          }}>
            <strong>💡 Tip:</strong> Salary changes will be automatically applied in the monthly projection based on the effective date.
          </div>
        )}
      </div>

      <div className="settings-section">
        <h3>Currency</h3>
        <div className="form-group">
          <label>Currency Symbol/Code:</label>
          <input
            type="text"
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            placeholder="e.g., SAR, USD, EUR, £, ¥"
            maxLength={10}
          />
          <small className="help-text">
            This will be displayed with all amounts throughout the application
          </small>
        </div>
      </div>

      <div className="settings-section">
        <h3>Expense Categories</h3>
        <p className="section-description">
          Manage your custom expense categories. These categories will be available for monthly expenses and daily transactions.
        </p>
        
        <div className="categories-list">
          {categories.map((category, index) => (
            <div key={index} className="category-item">
              <span className="category-name">{category}</span>
              <div className="category-actions">
                <button 
                  onClick={() => moveCategory(index, 'up')} 
                  disabled={index === 0}
                  className="btn-icon"
                  title="Move up"
                >
                  ▲
                </button>
                <button 
                  onClick={() => moveCategory(index, 'down')} 
                  disabled={index === categories.length - 1}
                  className="btn-icon"
                  title="Move down"
                >
                  ▼
                </button>
                <button 
                  onClick={() => removeCategory(index)}
                  className="btn-icon btn-delete"
                  title="Remove"
                >
                  ✕
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="add-category">
          <input
            type="text"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addCategory()}
            placeholder="Add new category"
          />
          <button onClick={addCategory} className="btn-add">
            Add Category
          </button>
        </div>
      </div>

      <div className="settings-actions">
        <button onClick={saveSettings} className="btn-save">
          Save Settings
        </button>
      </div>

      <style jsx>{`
        .settings-container {
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }

        .settings-section {
          background: white;
          padding: 25px;
          margin-bottom: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .settings-section h3 {
          margin-top: 0;
          color: #333;
          border-bottom: 2px solid #4CAF50;
          padding-bottom: 10px;
        }

        .section-description {
          color: #666;
          margin-bottom: 20px;
          font-size: 14px;
        }

        .form-group {
          margin-bottom: 20px;
        }

        .form-group label {
          display: block;
          margin-bottom: 8px;
          font-weight: 500;
          color: #555;
        }

        .form-group input {
          width: 100%;
          max-width: 300px;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 16px;
        }

        .help-text {
          display: block;
          margin-top: 6px;
          color: #888;
          font-size: 13px;
        }

        .categories-list {
          margin-bottom: 20px;
        }

        .category-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px;
          margin-bottom: 8px;
          background: #f8f9fa;
          border: 1px solid #e0e0e0;
          border-radius: 4px;
        }

        .category-name {
          flex: 1;
          font-size: 15px;
          color: #333;
        }

        .category-actions {
          display: flex;
          gap: 5px;
        }

        .btn-icon {
          background: white;
          border: 1px solid #ddd;
          border-radius: 4px;
          width: 32px;
          height: 32px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          transition: all 0.2s;
        }

        .btn-icon:hover:not(:disabled) {
          background: #f0f0f0;
          border-color: #999;
        }

        .btn-icon:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .btn-delete {
          color: #f44336;
          font-weight: bold;
        }

        .btn-delete:hover {
          background: #ffebee;
          border-color: #f44336;
        }

        .add-category {
          display: flex;
          gap: 10px;
          margin-top: 15px;
        }

        .add-category input {
          flex: 1;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 15px;
        }

        .btn-add {
          padding: 10px 20px;
          background: #4CAF50;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 15px;
          font-weight: 500;
          transition: background 0.2s;
        }

        .btn-add:hover {
          background: #45a049;
        }

        .settings-actions {
          text-align: center;
          margin-top: 30px;
        }

        .btn-save {
          padding: 12px 40px;
          background: #2196F3;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 16px;
          font-weight: 500;
          transition: background 0.2s;
        }

        .btn-save:hover {
          background: #0b7dda;
        }

        .message {
          padding: 15px;
          margin-bottom: 20px;
          border-radius: 4px;
          text-align: center;
          font-weight: 500;
        }

        .message.success {
          background: #d4edda;
          color: #155724;
          border: 1px solid #c3e6cb;
        }

        .message.error {
          background: #f8d7da;
          color: #721c24;
          border: 1px solid #f5c6cb;
        }
      `}</style>
    </div>
  );
};

export default Settings;
