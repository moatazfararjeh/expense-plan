import React from 'react';

function Summary({ summary, currency = 'SAR', salaryVisible = true, toggleSalaryVisibility }) {
  const {
    monthly_salary = 0,
    additional_monthly_income = 0,
    total_monthly_income = 0,
    monthly_recurring_expenses = 0,
    monthly_net = 0,
    yearly_salary = 0,
    yearly_additional_income = 0,
    total_yearly_income = 0,
    yearly_recurring_expenses = 0,
    yearly_daily_expenses = 0,
    total_yearly_expenses = 0,
    yearly_savings = 0
  } = summary;

  const formatSalary = (amount) => {
    return salaryVisible ? amount.toLocaleString() : '••••••';
  };

  return (
    <div className="summary-card card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h2>📊 Financial Summary - One Year Projection</h2>
        {toggleSalaryVisibility && (
          <button 
            onClick={toggleSalaryVisibility}
            className="salary-toggle-btn"
            title={salaryVisible ? 'Hide Salary' : 'Show Salary'}
            style={{
              background: 'rgba(255, 255, 255, 0.15)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              borderRadius: '8px',
              padding: '8px 16px',
              cursor: 'pointer',
              fontSize: '1.2rem',
              transition: 'all 0.3s ease',
              color: '#fff'
            }}
          >
            {salaryVisible ? '🙈' : '👁️'} {salaryVisible ? 'Hide' : 'Show'}
          </button>
        )}
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Monthly Salary:</span>
        <span className="summary-value">{formatSalary(monthly_salary)} {salaryVisible ? currency : ''}</span>
      </div>
      
      {additional_monthly_income > 0 && (
        <div className="summary-item">
          <span className="summary-label">Additional Monthly Income:</span>
          <span className="summary-value" style={{ color: '#2ecc71' }}>
            +{additional_monthly_income.toLocaleString()} {currency}
          </span>
        </div>
      )}
      
      <div className="summary-item">
        <span className="summary-label">Total Monthly Income:</span>
        <span className="summary-value" style={{ fontSize: '1.2rem' }}>
          {total_monthly_income.toLocaleString()} {currency}
        </span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Monthly Recurring Expenses:</span>
        <span className="summary-value">{monthly_recurring_expenses.toLocaleString()} {currency}</span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Monthly Net (Income - Recurring):</span>
        <span className="summary-value">{monthly_net.toLocaleString()} {currency}</span>
      </div>
      
      <div className="summary-item" style={{ marginTop: '20px', paddingTop: '20px', borderTop: '2px solid rgba(255,255,255,0.3)' }}>
        <span className="summary-label">Yearly Salary (12 months):</span>
        <span className="summary-value">{formatSalary(yearly_salary)} {salaryVisible ? currency : ''}</span>
      </div>
      
      {yearly_additional_income > 0 && (
        <div className="summary-item">
          <span className="summary-label">Yearly Additional Income:</span>
          <span className="summary-value" style={{ color: '#2ecc71' }}>
            +{yearly_additional_income.toLocaleString()} {currency}
          </span>
        </div>
      )}
      
      <div className="summary-item">
        <span className="summary-label">Total Yearly Income:</span>
        <span className="summary-value" style={{ fontSize: '1.2rem' }}>
          {total_yearly_income.toLocaleString()} {currency}
        </span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Yearly Recurring Expenses:</span>
        <span className="summary-value">{yearly_recurring_expenses.toLocaleString()} {currency}</span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Daily Transactions Total:</span>
        <span className="summary-value">{yearly_daily_expenses.toLocaleString()} {currency}</span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">Total Yearly Expenses:</span>
        <span className="summary-value">{total_yearly_expenses.toLocaleString()} {currency}</span>
      </div>
      
      <div className="summary-item">
        <span className="summary-label">💰 Projected Yearly Savings:</span>
        <span className={`summary-value ${yearly_savings >= 0 ? 'positive' : 'negative'}`}>
          {yearly_savings.toLocaleString()} {currency}
        </span>
      </div>
      
      {yearly_savings < 0 && (
        <div style={{ marginTop: '15px', padding: '10px', background: 'rgba(231, 76, 60, 0.2)', borderRadius: '8px' }}>
          ⚠️ Warning: Your expenses exceed your income!
        </div>
      )}
      
      {yearly_savings > 0 && (
        <div style={{ marginTop: '15px', padding: '10px', background: 'rgba(46, 204, 113, 0.2)', borderRadius: '8px' }}>
          ✅ Great! You're saving {((yearly_savings / total_yearly_income) * 100).toFixed(1)}% of your yearly income
        </div>
      )}
    </div>
  );
}

export default Summary;
