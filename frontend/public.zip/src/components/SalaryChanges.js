import React, { useState } from 'react';

function SalaryChanges({ salaryChanges, onAdd, onDelete }) {
  const [amount, setAmount] = useState('');
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (amount && amount > 0 && effectiveDate) {
      onAdd({ 
        amount: parseFloat(amount), 
        effective_date: effectiveDate,
        notes 
      });
      setAmount('');
      setEffectiveDate(new Date().toISOString().split('T')[0]);
      setNotes('');
      setShowForm(false);
    } else {
      alert('Please enter a valid amount and date');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h2>📈 Salary Changes (تغييرات الراتب)</h2>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="btn btn-primary"
          style={{ padding: '8px 16px', fontSize: '0.9rem' }}
        >
          {showForm ? 'Cancel' : '+ Add Change'}
        </button>
      </div>
      
      {showForm && (
        <form onSubmit={handleSubmit} style={{ 
          padding: '15px', 
          background: '#f8f9fa', 
          borderRadius: '8px',
          marginBottom: '20px'
        }}>
          <div className="form-group">
            <label htmlFor="salary-amount">New Salary Amount</label>
            <input
              type="number"
              id="salary-amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g., 35000"
              step="0.01"
              min="0"
            />
          </div>
          <div className="form-group">
            <label htmlFor="effective-date">Effective Date (تاريخ التطبيق)</label>
            <input
              type="date"
              id="effective-date"
              value={effectiveDate}
              onChange={(e) => setEffectiveDate(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="salary-notes">Notes (Optional)</label>
            <input
              type="text"
              id="salary-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Annual raise, Promotion"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Add Salary Change
          </button>
        </form>
      )}

      <div className="salary-changes-list">
        {salaryChanges.length > 0 ? (
          <>
            <div style={{ marginBottom: '10px', fontSize: '0.9rem', color: '#666' }}>
              {salaryChanges.length} salary change{salaryChanges.length !== 1 ? 's' : ''} recorded
            </div>
            {salaryChanges.map((change) => (
              <div key={change.id} style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '15px',
                background: 'white',
                border: '2px solid #e0e0e0',
                borderRadius: '8px',
                marginBottom: '10px'
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '1.3rem', fontWeight: 'bold', color: '#2ecc71' }}>
                    ${parseFloat(change.amount).toLocaleString()}
                  </div>
                  <div style={{ fontSize: '0.9rem', color: '#667eea', marginTop: '5px' }}>
                    📅 Effective: {formatDate(change.effective_date)}
                  </div>
                  {change.notes && (
                    <div style={{ fontSize: '0.85rem', color: '#666', marginTop: '5px', fontStyle: 'italic' }}>
                      {change.notes}
                    </div>
                  )}
                </div>
                <button 
                  className="btn btn-danger"
                  onClick={() => onDelete(change.id)}
                  style={{ marginLeft: '10px' }}
                >
                  Delete
                </button>
              </div>
            ))}
          </>
        ) : (
          <div className="empty-state" style={{ textAlign: 'center', padding: '20px', color: '#999' }}>
            No salary changes recorded yet. Current salary will be used for all months.
          </div>
        )}
      </div>

      {salaryChanges.length > 0 && (
        <div style={{ 
          marginTop: '15px', 
          padding: '15px', 
          background: '#e3f2fd', 
          borderRadius: '8px',
          fontSize: '0.9rem',
          color: '#1976d2'
        }}>
          <strong>💡 Tip:</strong> Salary changes will be automatically applied in the monthly projection based on the effective date.
        </div>
      )}
    </div>
  );
}

export default SalaryChanges;
