import React, { useState } from 'react';

function AdditionalIncome({ incomes, onAdd, onDelete }) {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [frequency, setFrequency] = useState('Monthly');
  const [category, setCategory] = useState('Freelance');
  const [incomeMonth, setIncomeMonth] = useState('1'); // For one-time income

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && amount && amount > 0) {
      const incomeData = { 
        name, 
        amount: parseFloat(amount), 
        frequency, 
        category
      };
      
      // Add income_month only for one-time income
      if (frequency === 'One-time') {
        incomeData.income_month = parseInt(incomeMonth);
      }
      
      onAdd(incomeData);
      setName('');
      setAmount('');
      setFrequency('Monthly');
      setCategory('Freelance');
      setIncomeMonth('1');
    } else {
      alert('Please fill in all fields correctly');
    }
  };

  // Calculate total monthly income from all sources
  const calculateMonthlyIncome = (income) => {
    const amount = parseFloat(income.amount);
    switch(income.frequency) {
      case 'One-time':
        return 0; // One-time doesn't count as recurring monthly income
      case 'Weekly':
        return amount * 4.33; // avg weeks per month
      case 'Bi-weekly':
        return amount * 2.17; // avg bi-weeks per month
      case 'Monthly':
        return amount;
      case 'Yearly':
        return amount / 12;
      default:
        return amount;
    }
  };

  const totalAdditionalIncome = incomes.reduce((sum, income) => 
    sum + calculateMonthlyIncome(income), 0
  );

  return (
    <div className="card">
      <h2>💵 Additional Income Sources</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="income-name">Income Source Name</label>
          <input
            type="text"
            id="income-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Freelance work"
          />
        </div>
        <div className="form-group">
          <label htmlFor="income-amount">Amount</label>
          <input
            type="number"
            id="income-amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 1000"
            step="0.01"
            min="0"
          />
        </div>
        <div className="form-group">
          <label htmlFor="income-frequency">Frequency</label>
          <select
            id="income-frequency"
            value={frequency}
            onChange={(e) => setFrequency(e.target.value)}
          >
            <option value="One-time">One-time (مرة واحدة)</option>
            <option value="Weekly">Weekly</option>
            <option value="Bi-weekly">Bi-weekly</option>
            <option value="Monthly">Monthly</option>
            <option value="Yearly">Yearly</option>
          </select>
        </div>
        
        {/* Show month selector only for one-time income */}
        {frequency === 'One-time' && (
          <div className="form-group">
            <label htmlFor="income-month">Which Month? (أي شهر؟)</label>
            <select
              id="income-month"
              value={incomeMonth}
              onChange={(e) => setIncomeMonth(e.target.value)}
            >
              <option value="1">January (يناير)</option>
              <option value="2">February (فبراير)</option>
              <option value="3">March (مارس)</option>
              <option value="4">April (إبريل)</option>
              <option value="5">May (مايو)</option>
              <option value="6">June (يونيو)</option>
              <option value="7">July (يوليو)</option>
              <option value="8">August (أغسطس)</option>
              <option value="9">September (سبتمبر)</option>
              <option value="10">October (أكتوبر)</option>
              <option value="11">November (نوفمبر)</option>
              <option value="12">December (ديسمبر)</option>
            </select>
          </div>
        )}
        <div className="form-group">
          <label htmlFor="income-category">Category</label>
          <select
            id="income-category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="Freelance">Freelance</option>
            <option value="Side Business">Side Business</option>
            <option value="Rental Income">Rental Income</option>
            <option value="Investments">Investments</option>
            <option value="Bonuses">Bonuses</option>
            <option value="Commission">Commission</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary">
          Add Income Source
        </button>
      </form>

      <div className="expense-list">
        {incomes.length > 0 ? (
          <>
            {incomes.map((income) => {
              const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
              const isOneTime = income.frequency === 'One-time';
              
              return (
              <div key={income.id} className="expense-item">
                <div className="expense-details">
                  <div className="expense-name">
                    {income.name}
                    <span style={{ 
                      marginLeft: '10px', 
                      fontSize: '0.85rem', 
                      padding: '3px 8px', 
                      background: isOneTime ? '#f59e0b' : '#667eea', 
                      color: 'white', 
                      borderRadius: '4px' 
                    }}>
                      {income.frequency}
                      {isOneTime && income.income_month && ` - ${monthNames[income.income_month - 1]}`}
                    </span>
                  </div>
                  <div className="expense-category">
                    {income.category} • ${parseFloat(income.amount).toLocaleString()}/{income.frequency.toLowerCase()}
                    {income.frequency !== 'Monthly' && income.frequency !== 'One-time' && (
                      <span style={{ color: '#667eea', marginLeft: '5px' }}>
                        (≈ ${calculateMonthlyIncome(income).toLocaleString()}/month)
                      </span>
                    )}
                    {isOneTime && income.income_month && (
                      <span style={{ color: '#f59e0b', marginLeft: '5px', fontWeight: 'bold' }}>
                        ⚡ Applies to {monthNames[income.income_month - 1]} only
                      </span>
                    )}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  {isOneTime ? (
                    <span className="expense-amount" style={{ color: '#f59e0b', fontWeight: 'bold' }}>
                      ${parseFloat(income.amount).toLocaleString()} (once)
                    </span>
                  ) : (
                    <span className="expense-amount" style={{ color: '#2ecc71' }}>
                      ${calculateMonthlyIncome(income).toLocaleString()}/mo
                    </span>
                  )}
                  <button 
                    className="btn btn-danger"
                    onClick={() => onDelete(income.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
              );
            })}
            <div style={{ 
              marginTop: '15px', 
              fontSize: '1.1rem', 
              fontWeight: 'bold', 
              textAlign: 'right', 
              color: '#2ecc71',
              padding: '10px',
              background: '#d4edda',
              borderRadius: '8px'
            }}>
              Total Additional Income: ${totalAdditionalIncome.toLocaleString()}/month
            </div>
          </>
        ) : (
          <div className="empty-state">No additional income sources added yet</div>
        )}
      </div>
    </div>
  );
}

export default AdditionalIncome;
