import React, { useState } from 'react';

function MonthlyExpenses({ expenses, onAdd, onUpdate, onDelete, categories = ['Jordan Family Expense', 'Our Expense', 'Loan Sabb', 'Other'], currency = 'SAR' }) {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(categories[0] || 'Other');
  const [startMonth, setStartMonth] = useState(1);
  const [endMonth, setEndMonth] = useState(12);
  const [startYear, setStartYear] = useState(new Date().getFullYear());
  const [endYear, setEndYear] = useState(new Date().getFullYear());
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' }
  ];

  // Generate year options (2024-2030)
  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 2; i <= currentYear + 4; i++) {
    years.push(i);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && amount && amount > 0) {
      if (isEditing) {
        // Update existing expense
        onUpdate(editingId, { 
          name, 
          amount: parseFloat(amount), 
          category,
          start_month: parseInt(startMonth),
          end_month: parseInt(endMonth),
          start_year: parseInt(startYear),
          end_year: parseInt(endYear)
        });
        setIsEditing(false);
        setEditingId(null);
      } else {
        // Add new expense
        onAdd({ 
          name, 
          amount: parseFloat(amount), 
          category,
          start_month: parseInt(startMonth),
          end_month: parseInt(endMonth),
          start_year: parseInt(startYear),
          end_year: parseInt(endYear)
        });
      }
      // Reset form
      setName('');
      setAmount('');
      setCategory(categories[0] || 'Other');
      setStartMonth(1);
      setEndMonth(12);
      setStartYear(new Date().getFullYear());
      setEndYear(new Date().getFullYear());
    } else {
      alert('Please fill in all fields correctly');
    }
  };

  const handleEdit = (expense) => {
    setIsEditing(true);
    setEditingId(expense.id);
    setName(expense.name);
    setAmount(expense.amount.toString());
    setCategory(expense.category);
    setStartMonth(expense.start_month || 1);
    setEndMonth(expense.end_month || 12);
    setStartYear(expense.start_year || new Date().getFullYear());
    setEndYear(expense.end_year || new Date().getFullYear());
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditingId(null);
    setName('');
    setAmount('');
    setCategory(categories[0] || 'Other');
    setStartMonth(1);
    setEndMonth(12);
    setStartYear(new Date().getFullYear());
    setEndYear(new Date().getFullYear());
  };

  const getMonthName = (monthNum) => {
    const month = months.find(m => m.value === parseInt(monthNum));
    return month ? month.label : '';
  };

  const calculateMonthsActive = (expense) => {
    const startMonth = expense.start_month || 1;
    const endMonth = expense.end_month || 12;
    const startYear = expense.start_year || new Date().getFullYear();
    const endYear = expense.end_year || new Date().getFullYear();
    
    if (startYear === endYear) {
      // Same year
      if (endMonth >= startMonth) {
        return endMonth - startMonth + 1;
      } else {
        return 12 - startMonth + endMonth + 1; // wraps around year
      }
    } else {
      // Different years
      const monthsInStartYear = 12 - startMonth + 1;
      const monthsInEndYear = endMonth;
      const fullYears = endYear - startYear - 1;
      return monthsInStartYear + (fullYears * 12) + monthsInEndYear;
    }
  };

  const totalMonthly = expenses.reduce((sum, exp) => {
    const monthsActive = calculateMonthsActive(exp);
    const yearlyTotal = parseFloat(exp.amount) * monthsActive;
    return sum + yearlyTotal;
  }, 0);

  const avgMonthly = expenses.length > 0 ? totalMonthly / 12 : 0;

  // Category icons and colors
  const getCategoryIcon = (category) => {
    const icons = {
      'Jordan Family Expense': '👨‍👩‍👧‍👦',
      'Our Expense': '🏠',
      'Loan Sabb': '🏦',
      'Other': '📦'
    };
    return icons[category] || '💰';
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Jordan Family Expense': '#FF6B6B',
      'Our Expense': '#4ECDC4',
      'Loan Sabb': '#FFD93D',
      'Other': '#95E1D3'
    };
    return colors[category] || '#A8DADC';
  };

  // Check if expense is active now
  const getExpenseStatus = (expense) => {
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();
    
    const startYear = expense.start_year || currentYear;
    const startMonth = expense.start_month || 1;
    const endYear = expense.end_year || currentYear;
    const endMonth = expense.end_month || 12;
    
    const startDate = new Date(startYear, startMonth - 1);
    const endDate = new Date(endYear, endMonth - 1);
    const nowDate = new Date(currentYear, currentMonth - 1);
    
    if (nowDate < startDate) return 'upcoming';
    if (nowDate > endDate) return 'expired';
    return 'active';
  };

  const getStatusBadge = (status) => {
    const badges = {
      'active': { label: '✓ Active', color: '#10B981', bg: '#D1FAE5' },
      'upcoming': { label: '⏱️ Upcoming', color: '#F59E0B', bg: '#FEF3C7' },
      'expired': { label: '✕ Expired', color: '#EF4444', bg: '#FEE2E2' }
    };
    return badges[status] || badges.active;
  };

  return (
    <div className="card">
      <h2>📝 Monthly Recurring Expenses</h2>
      <form onSubmit={handleSubmit}>
        {isEditing && (
          <div style={{ 
            padding: '10px', 
            background: '#fff3cd', 
            borderRadius: '8px', 
            marginBottom: '15px',
            border: '1px solid #ffc107',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <span style={{ color: '#856404', fontWeight: 'bold' }}>
              ✏️ Editing: {name || 'Expense'}
            </span>
            <button 
              type="button" 
              onClick={handleCancelEdit}
              style={{
                background: '#6c757d',
                color: 'white',
                border: 'none',
                padding: '5px 15px',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '0.9rem'
              }}
            >
              Cancel
            </button>
          </div>
        )}
        <div className="form-group">
          <label htmlFor="expense-name">Expense Name</label>
          <input
            type="text"
            id="expense-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., School fees"
          />
        </div>
        <div className="form-group">
          <label htmlFor="expense-amount">Amount</label>
          <input
            type="number"
            id="expense-amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 2000"
            step="0.01"
            min="0"
          />
        </div>
        <div className="form-group">
          <label htmlFor="expense-category">Category</label>
          <select
            id="expense-category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="start-month">Start Month</label>
          <select
            id="start-month"
            value={startMonth}
            onChange={(e) => setStartMonth(e.target.value)}
          >
            {months.map(month => (
              <option key={month.value} value={month.value}>{month.label}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="start-year">Start Year</label>
          <select
            id="start-year"
            value={startYear}
            onChange={(e) => setStartYear(e.target.value)}
          >
            {years.map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="end-month">End Month</label>
          <select
            id="end-month"
            value={endMonth}
            onChange={(e) => setEndMonth(e.target.value)}
          >
            {months.map(month => (
              <option key={month.value} value={month.value}>{month.label}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="end-year">End Year</label>
          <select
            id="end-year"
            value={endYear}
            onChange={(e) => setEndYear(e.target.value)}
          >
            {years.map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-primary">
          {isEditing ? 'Update Expense' : 'Add Expense'}
        </button>
      </form>

      <div className="expense-list">
        {expenses.length > 0 ? (
          <>
            {expenses.map((expense) => {
              const monthsActive = calculateMonthsActive(expense);
              const yearlyTotal = parseFloat(expense.amount) * monthsActive;
              const status = getExpenseStatus(expense);
              const statusBadge = getStatusBadge(status);
              const categoryColor = getCategoryColor(expense.category);
              const categoryIcon = getCategoryIcon(expense.category);
              
              // Check if expense spans across years (showing date range)
              const showDateRange = expense.start_year && expense.end_year && 
                                   (expense.start_year !== expense.end_year || 
                                    expense.start_month !== expense.end_month || 
                                    expense.start_month !== 1 || 
                                    expense.end_month !== 12);
              
              return (
                <div 
                  key={expense.id} 
                  className="expense-item"
                  style={{
                    background: '#ffffff',
                    padding: '20px',
                    marginBottom: '15px',
                    borderRadius: '12px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                    border: `3px solid ${categoryColor}20`,
                    transition: 'all 0.3s ease',
                    position: 'relative',
                    overflow: 'hidden'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.12)';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  {/* Category Color Bar */}
                  <div style={{
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    bottom: 0,
                    width: '6px',
                    background: categoryColor,
                    borderRadius: '12px 0 0 12px'
                  }} />
                  
                  {/* Action Buttons - Top Right */}
                  <div style={{ 
                    position: 'absolute',
                    top: '15px',
                    right: '15px',
                    display: 'flex',
                    gap: '8px',
                    zIndex: 10
                  }}>
                    <button 
                      className="btn btn-secondary"
                      onClick={() => handleEdit(expense)}
                      style={{
                        background: '#667eea',
                        color: 'white',
                        padding: '8px 16px',
                        border: 'none',
                        borderRadius: '8px',
                        cursor: 'pointer',
                        fontSize: '0.9rem',
                        fontWeight: '600',
                        transition: 'all 0.3s ease',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        whiteSpace: 'nowrap'
                      }}
                      onMouseOver={(e) => e.currentTarget.style.background = '#5568d3'}
                      onMouseOut={(e) => e.currentTarget.style.background = '#667eea'}
                    >
                      ✏️ Edit
                    </button>
                    <button 
                      className="btn btn-danger"
                      onClick={() => onDelete(expense.id)}
                      style={{
                        background: '#EF4444',
                        color: 'white',
                        padding: '8px 16px',
                        border: 'none',
                        borderRadius: '8px',
                        cursor: 'pointer',
                        fontSize: '0.9rem',
                        fontWeight: '600',
                        transition: 'all 0.3s ease',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        whiteSpace: 'nowrap'
                      }}
                      onMouseOver={(e) => e.currentTarget.style.background = '#DC2626'}
                      onMouseOut={(e) => e.currentTarget.style.background = '#EF4444'}
                    >
                      🗑️ Delete
                    </button>
                  </div>
                  
                  {/* Main Content - Full Width */}
                  <div className="expense-details" style={{ width: '100%', paddingRight: '200px' }}>
                    {/* Header with Status Badge */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '1.5rem' }}>{categoryIcon}</span>
                        <div className="expense-name" style={{ 
                          fontSize: '1.2rem', 
                          fontWeight: '700',
                          color: '#2D3748'
                        }}>
                          {expense.name}
                        </div>
                        <span style={{
                          background: statusBadge.bg,
                          color: statusBadge.color,
                          padding: '4px 10px',
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: '600',
                          textTransform: 'uppercase',
                          letterSpacing: '0.5px'
                        }}>
                          {statusBadge.label}
                        </span>
                      </div>
                      
                      {/* Category and Amount */}
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        flexWrap: 'wrap',
                        marginBottom: '10px'
                      }}>
                        <span style={{
                          background: `${categoryColor}20`,
                          color: categoryColor,
                          padding: '6px 12px',
                          borderRadius: '8px',
                          fontSize: '0.85rem',
                          fontWeight: '600'
                        }}>
                          {expense.category}
                        </span>
                        <span style={{
                          fontSize: '1.3rem',
                          fontWeight: '700',
                          color: '#667eea'
                        }}>
                          {parseFloat(expense.amount).toLocaleString()} {currency}
                          <span style={{ fontSize: '0.8rem', fontWeight: '500', color: '#718096' }}>/month</span>
                        </span>
                      </div>
                      
                      {/* Date Range and Total */}
                      {showDateRange && (
                        <div style={{
                          background: '#F7FAFC',
                          padding: '12px',
                          borderRadius: '8px',
                          marginTop: '10px'
                        }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                            <span style={{ fontSize: '0.9rem', color: '#4A5568' }}>
                              📅 <strong>{getMonthName(expense.start_month)} {expense.start_year}</strong> → <strong>{getMonthName(expense.end_month)} {expense.end_year}</strong>
                            </span>
                          </div>
                          <div style={{ display: 'flex', gap: '15px', fontSize: '0.9rem' }}>
                            <span style={{ color: '#667eea', fontWeight: '600' }}>
                              ⏱️ {monthsActive} months
                            </span>
                            <span style={{ color: '#10B981', fontWeight: '700' }}>
                              💰 Total: {yearlyTotal.toLocaleString()} {currency}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                </div>
              );
            })}
            <div style={{ 
              marginTop: '20px', 
              padding: '20px', 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '12px',
              boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)',
              color: 'white'
            }}>
              <div style={{ 
                fontSize: '1rem', 
                marginBottom: '10px',
                opacity: 0.9,
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <span>📊</span>
                <span>Total Yearly Recurring: <strong>{totalMonthly.toLocaleString()} {currency}</strong></span>
              </div>
              <div style={{ 
                fontSize: '1.3rem', 
                fontWeight: 'bold',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <span>💵</span>
                <span>Average per Month: {avgMonthly.toLocaleString()} {currency}/month</span>
              </div>
            </div>
          </>
        ) : (
          <div className="empty-state" style={{
            textAlign: 'center',
            padding: '60px 20px',
            color: '#A0AEC0',
            fontSize: '1.1rem'
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '15px' }}>📝</div>
            <div style={{ fontWeight: '600', color: '#4A5568' }}>No monthly expenses added yet</div>
            <div style={{ fontSize: '0.9rem', marginTop: '8px' }}>Add your first recurring expense using the form above</div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MonthlyExpenses;
