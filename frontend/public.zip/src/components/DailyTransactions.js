import React, { useState } from 'react';

function DailyTransactions({ transactions, onAdd, onDelete, categories = ['Jordan Family Expense', 'Our Expense', 'Loan Sabb', 'Other'], currency = 'SAR' }) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState(categories[0] || 'Other');
  
  // Edit mode state
  const [editingId, setEditingId] = useState(null);
  const [editDescription, setEditDescription] = useState('');
  const [editAmount, setEditAmount] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editCategory, setEditCategory] = useState('');
  
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());

  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (description && amount && amount > 0 && date) {
      onAdd({ 
        description, 
        amount: parseFloat(amount), 
        transaction_date: date,
        category 
      });
      setDescription('');
      setAmount('');
      setDate(new Date().toISOString().split('T')[0]);
      setCategory(categories[0] || 'Other');
    } else {
      alert('Please fill in all fields correctly');
    }
  };

  const startEdit = (transaction) => {
    setEditingId(transaction.id);
    setEditDescription(transaction.description);
    setEditAmount(transaction.amount);
    setEditDate(transaction.transaction_date);
    setEditCategory(transaction.category);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditDescription('');
    setEditAmount('');
    setEditDate('');
    setEditCategory('');
  };

  const updateTransaction = async (id) => {
    if (editDescription && editAmount && editAmount > 0 && editDate) {
      // Call backend API to update (you'll need to add this to App.js)
      try {
        await onAdd({ 
          id,
          description: editDescription, 
          amount: parseFloat(editAmount), 
          transaction_date: editDate,
          category: editCategory,
          isUpdate: true
        });
        cancelEdit();
      } catch (error) {
        alert('Failed to update transaction');
      }
    } else {
      alert('Please fill in all fields correctly');
    }
  };

  // Filter transactions by selected month and year
  const filteredTransactions = transactions.filter(trans => {
    const transDate = new Date(trans.transaction_date);
    return transDate.getMonth() + 1 === parseInt(selectedMonth) && 
           transDate.getFullYear() === parseInt(selectedYear);
  });

  // Group transactions by date
  const groupedByDate = filteredTransactions.reduce((groups, trans) => {
    const date = new Date(trans.transaction_date).toLocaleDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(trans);
    return groups;
  }, {});

  // Sort dates in descending order (most recent first)
  const sortedDates = Object.keys(groupedByDate).sort((a, b) => {
    return new Date(b) - new Date(a);
  });

  const totalTransactions = filteredTransactions.reduce((sum, trans) => sum + parseFloat(trans.amount), 0);

  // Get available years from transactions
  const availableYears = [...new Set(transactions.map(trans => 
    new Date(trans.transaction_date).getFullYear()
  ))].sort((a, b) => b - a);
  
  if (availableYears.length === 0) {
    availableYears.push(currentDate.getFullYear());
  }

  return (
    <div className="card">
      <h2>💳 Daily Transactions</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="trans-desc">Description</label>
          <input
            type="text"
            id="trans-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g., Grocery shopping"
          />
        </div>
        <div className="form-group">
          <label htmlFor="trans-amount">Amount</label>
          <input
            type="number"
            id="trans-amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 50"
            step="0.01"
            min="0"
          />
        </div>
        <div className="form-group">
          <label htmlFor="trans-date">Date</label>
          <input
            type="date"
            id="trans-date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="trans-category">Category</label>
          <select
            id="trans-category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-primary">
          Add Transaction
        </button>
      </form>

      <div className="filter-section" style={{ marginTop: '20px', marginBottom: '20px', padding: '15px', background: '#f8f9fa', borderRadius: '8px' }}>
        <h3 style={{ marginBottom: '10px', fontSize: '1rem' }}>📅 View Transactions By Month</h3>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: '1', minWidth: '150px' }}>
            <label htmlFor="filter-month" style={{ display: 'block', marginBottom: '5px', fontSize: '0.9rem', fontWeight: '600' }}>Month</label>
            <select
              id="filter-month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd' }}
            >
              {months.map(month => (
                <option key={month.value} value={month.value}>{month.label}</option>
              ))}
            </select>
          </div>
          <div style={{ flex: '1', minWidth: '120px' }}>
            <label htmlFor="filter-year" style={{ display: 'block', marginBottom: '5px', fontSize: '0.9rem', fontWeight: '600' }}>Year</label>
            <select
              id="filter-year"
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd' }}
            >
              {availableYears.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
          <button 
            onClick={() => {
              setSelectedMonth(currentDate.getMonth() + 1);
              setSelectedYear(currentDate.getFullYear());
            }}
            style={{ padding: '8px 16px', marginTop: '20px', borderRadius: '4px', border: '1px solid #667eea', background: 'white', color: '#667eea', cursor: 'pointer', fontWeight: '600' }}
          >
            Current Month
          </button>
        </div>
        <div style={{ marginTop: '10px', fontSize: '0.9rem', color: '#666' }}>
          Showing {filteredTransactions.length} transaction(s) for {months[selectedMonth - 1].label} {selectedYear}
        </div>
      </div>

      <div className="transaction-list">
        {filteredTransactions.length > 0 ? (
          <>
            {sortedDates.map(date => (
              <div key={date} style={{ marginBottom: '20px' }}>
                <div style={{ 
                  fontSize: '0.95rem', 
                  fontWeight: 'bold', 
                  color: '#667eea', 
                  marginBottom: '10px',
                  paddingBottom: '5px',
                  borderBottom: '2px solid #667eea'
                }}>
                  {date} ({groupedByDate[date].length} transaction{groupedByDate[date].length !== 1 ? 's' : ''})
                </div>
                {groupedByDate[date].map((transaction) => (
                  <div key={transaction.id} className="transaction-item" style={{ marginLeft: '10px' }}>
                    {editingId === transaction.id ? (
                      // Edit mode
                      <div style={{ padding: '10px', background: '#f0f4ff', borderRadius: '8px', marginBottom: '10px' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                          <div>
                            <label style={{ fontSize: '0.85rem', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Description</label>
                            <input
                              type="text"
                              value={editDescription}
                              onChange={(e) => setEditDescription(e.target.value)}
                              style={{ width: '100%', padding: '6px', borderRadius: '4px', border: '1px solid #ddd' }}
                            />
                          </div>
                          <div>
                            <label style={{ fontSize: '0.85rem', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Amount ({currency})</label>
                            <input
                              type="number"
                              value={editAmount}
                              onChange={(e) => setEditAmount(e.target.value)}
                              step="0.01"
                              min="0"
                              style={{ width: '100%', padding: '6px', borderRadius: '4px', border: '1px solid #ddd' }}
                            />
                          </div>
                          <div>
                            <label style={{ fontSize: '0.85rem', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Date</label>
                            <input
                              type="date"
                              value={editDate}
                              onChange={(e) => setEditDate(e.target.value)}
                              style={{ width: '100%', padding: '6px', borderRadius: '4px', border: '1px solid #ddd' }}
                            />
                          </div>
                          <div>
                            <label style={{ fontSize: '0.85rem', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Category</label>
                            <select
                              value={editCategory}
                              onChange={(e) => setEditCategory(e.target.value)}
                              style={{ width: '100%', padding: '6px', borderRadius: '4px', border: '1px solid #ddd' }}
                            >
                              {categories.map(cat => (
                                <option key={cat} value={cat}>{cat}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: '10px' }}>
                          <button
                            onClick={() => updateTransaction(transaction.id)}
                            style={{ flex: 1, padding: '8px', background: '#667eea', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '600' }}
                          >
                            Save
                          </button>
                          <button
                            onClick={cancelEdit}
                            style={{ flex: 1, padding: '8px', background: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '600' }}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      // View mode
                      <>
                        <div className="transaction-details">
                          <div className="transaction-desc">{transaction.description}</div>
                          <div className="transaction-category">
                            {transaction.category}
                          </div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <span className="transaction-amount">{parseFloat(transaction.amount).toLocaleString()} {currency}</span>
                          <button 
                            className="btn btn-warning"
                            onClick={() => startEdit(transaction)}
                            style={{ background: '#ffc107', color: '#000', padding: '6px 12px', fontSize: '0.9rem' }}
                          >
                            Edit
                          </button>
                          <button 
                            className="btn btn-danger"
                            onClick={() => onDelete(transaction.id)}
                          >
                            Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
                <div style={{ 
                  marginTop: '8px', 
                  marginLeft: '10px',
                  fontSize: '0.9rem', 
                  fontWeight: '600', 
                  color: '#999',
                  textAlign: 'right',
                  paddingRight: '10px'
                }}>
                  Day Total: {groupedByDate[date].reduce((sum, t) => sum + parseFloat(t.amount), 0).toLocaleString()} {currency}
                </div>
              </div>
            ))}
            <div style={{ 
              marginTop: '20px', 
              padding: '15px', 
              background: '#667eea', 
              color: 'white',
              borderRadius: '8px',
              fontSize: '1.2rem', 
              fontWeight: 'bold', 
              textAlign: 'center'
            }}>
              {months[selectedMonth - 1].label} {selectedYear} Total: {totalTransactions.toLocaleString()} {currency}
            </div>
          </>
        ) : (
          <div className="empty-state">No transactions found for {months[selectedMonth - 1].label} {selectedYear}</div>
        )}
      </div>
    </div>
  );
}

export default DailyTransactions;
