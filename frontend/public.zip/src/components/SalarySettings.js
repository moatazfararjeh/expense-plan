import React, { useState } from 'react';

function SalarySettings({ salary, openingBalance, planStartDate, onUpdate }) {
  const [salaryInput, setSalaryInput] = useState(salary);
  const [balanceInput, setBalanceInput] = useState(openingBalance);
  const [startDateInput, setStartDateInput] = useState(planStartDate || new Date().toISOString().split('T')[0]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (salaryInput && salaryInput >= 0) {
      onUpdate(parseFloat(salaryInput), parseFloat(balanceInput || 0), startDateInput);
    } else {
      alert('Please enter a valid salary amount');
    }
  };

  return (
    <div className="card">
      <h2>💼 Salary & Plan Settings</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="salary">Monthly Salary</label>
          <input
            type="number"
            id="salary"
            value={salaryInput}
            onChange={(e) => setSalaryInput(e.target.value)}
            placeholder="e.g., 30000"
            step="0.01"
            min="0"
          />
        </div>
        <div className="form-group">
          <label htmlFor="opening-balance">Opening Balance (المبلغ الافتتاحي)</label>
          <input
            type="number"
            id="opening-balance"
            value={balanceInput}
            onChange={(e) => setBalanceInput(e.target.value)}
            placeholder="e.g., 5000"
            step="0.01"
            min="0"
          />
          <small style={{ display: 'block', marginTop: '5px', color: '#666', fontSize: '0.85rem' }}>
            المبلغ الموجود لديك قبل بدء الخطة
          </small>
        </div>
        <div className="form-group">
          <label htmlFor="plan-start-date">Plan Start Date (تاريخ بداية الخطة)</label>
          <input
            type="date"
            id="plan-start-date"
            value={startDateInput}
            onChange={(e) => setStartDateInput(e.target.value)}
          />
          <small style={{ display: 'block', marginTop: '5px', color: '#666', fontSize: '0.85rem' }}>
            تاريخ بدء تتبع المصروفات والمدخرات
          </small>
        </div>
        <button type="submit" className="btn btn-primary">
          Update Settings
        </button>
      </form>
      {salary > 0 && (
        <div style={{ marginTop: '15px', padding: '10px', background: '#f0f0f0', borderRadius: '8px' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: '#667eea' }}>
            Monthly Salary: ${salary.toLocaleString()}
          </div>
          {openingBalance > 0 && (
            <div style={{ fontSize: '1rem', marginTop: '5px', color: '#2ecc71', fontWeight: '600' }}>
              Opening Balance: ${openingBalance.toLocaleString()}
            </div>
          )}
          {planStartDate && (
            <div style={{ fontSize: '0.95rem', marginTop: '5px', color: '#666', fontWeight: '600' }}>
              📅 Plan Start: {new Date(planStartDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default SalarySettings;
