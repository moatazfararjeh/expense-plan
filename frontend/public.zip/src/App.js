import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import './responsive.css';
import { useAuth } from './context/AuthContext';
import Login from './components/Login';
import Register from './components/Register';
import Settings from './components/Settings';
import AdditionalIncome from './components/AdditionalIncome';
import MonthlyExpenses from './components/MonthlyExpenses';
import DailyTransactions from './components/DailyTransactions';
import ExpenseChart from './components/ExpenseChart';
import MonthlyProjection from './components/MonthlyProjection';
import MonthlyExpenseReport from './components/MonthlyExpenseReport';

const API_URL = process.env.REACT_APP_API_URL ? `${process.env.REACT_APP_API_URL}/api` : 'http://localhost:1000/api';

function App() {
  const { isAuthenticated, loading: authLoading, logout, user, getAuthHeader } = useAuth();
  const [showRegister, setShowRegister] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard'); // dashboard, transactions, reports, settings
  const [transactionSubTab, setTransactionSubTab] = useState('income'); // income, expenses, daily
  const [salary, setSalary] = useState(0);
  const [openingBalance, setOpeningBalance] = useState(0);
  const [planStartDate, setPlanStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [currency, setCurrency] = useState('SAR');
  const [categories, setCategories] = useState(['Jordan Family Expense', 'Our Expense', 'Loan Sabb', 'Other']);
  const [salaryChanges, setSalaryChanges] = useState([]);
  const [additionalIncomes, setAdditionalIncomes] = useState([]);
  const [monthlyExpenses, setMonthlyExpenses] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [salaryVisible, setSalaryVisible] = useState(true); // Toggle salary visibility

  // Fetch all data
  const fetchData = async () => {
    try {
      const headers = getAuthHeader();
      const [settingsRes, salaryChangesRes, incomesRes, expensesRes, transactionsRes] = await Promise.all([
        axios.get(`${API_URL}/settings`, { headers }),
        axios.get(`${API_URL}/salary-changes`, { headers }),
        axios.get(`${API_URL}/additional-income`, { headers }),
        axios.get(`${API_URL}/monthly-expenses`, { headers }),
        axios.get(`${API_URL}/transactions`, { headers })
      ]);

      setSalary(settingsRes.data.monthly_salary || 0);
      setOpeningBalance(settingsRes.data.opening_balance || 0);
      setPlanStartDate(settingsRes.data.plan_start_date || new Date().toISOString().split('T')[0]);
      setCurrency(settingsRes.data.currency || 'SAR');
      setCategories(settingsRes.data.categories || ['Jordan Family Expense', 'Our Expense', 'Loan Sabb', 'Other']);
      setSalaryChanges(salaryChangesRes.data);
      setAdditionalIncomes(incomesRes.data);
      setMonthlyExpenses(expensesRes.data);
      setTransactions(transactionsRes.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      if (error.response?.status === 401 || error.response?.status === 403) {
        logout();
      }
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  // Update settings (salary, opening balance, and plan start date)
  const updateSettings = async (newSalary, newOpeningBalance, newPlanStartDate) => {
    try {
      const headers = getAuthHeader();
      await axios.post(`${API_URL}/settings`, { 
        monthly_salary: newSalary, 
        opening_balance: newOpeningBalance,
        plan_start_date: newPlanStartDate
      }, { headers });
      setSalary(newSalary);
      setOpeningBalance(newOpeningBalance);
      setPlanStartDate(newPlanStartDate);
      fetchData();
    } catch (error) {
      console.error('Error updating settings:', error);
      alert('Failed to update settings');
    }
  };

  // Add additional income
  const addAdditionalIncome = async (income) => {
    try {
      const headers = getAuthHeader();
      const response = await axios.post(`${API_URL}/additional-income`, income, { headers });
      setAdditionalIncomes([response.data, ...additionalIncomes]);
      fetchData();
    } catch (error) {
      console.error('Error adding additional income:', error);
      alert('Failed to add income source');
    }
  };

  // Delete additional income
  const deleteAdditionalIncome = async (id) => {
    try {
      const headers = getAuthHeader();
      await axios.delete(`${API_URL}/additional-income/${id}`, { headers });
      setAdditionalIncomes(additionalIncomes.filter(inc => inc.id !== id));
      fetchData();
    } catch (error) {
      console.error('Error deleting additional income:', error);
      alert('Failed to delete income source');
    }
  };

  // Add salary change
  const addSalaryChange = async (change) => {
    try {
      const headers = getAuthHeader();
      const response = await axios.post(`${API_URL}/salary-changes`, change, { headers });
      setSalaryChanges([...salaryChanges, response.data]);
      fetchData();
    } catch (error) {
      console.error('Error adding salary change:', error);
      alert('Failed to add salary change');
    }
  };

  // Delete salary change
  const deleteSalaryChange = async (id) => {
    try {
      const headers = getAuthHeader();
      await axios.delete(`${API_URL}/salary-changes/${id}`, { headers });
      setSalaryChanges(salaryChanges.filter(change => change.id !== id));
      fetchData();
    } catch (error) {
      console.error('Error deleting salary change:', error);
      alert('Failed to delete salary change');
    }
  };

  // Add monthly expense
  const addMonthlyExpense = async (expense) => {
    try {
      const headers = getAuthHeader();
      const response = await axios.post(`${API_URL}/monthly-expenses`, expense, { headers });
      setMonthlyExpenses([response.data, ...monthlyExpenses]);
      fetchData();
    } catch (error) {
      console.error('Error adding monthly expense:', error);
      alert('Failed to add expense');
    }
  };

  // Delete monthly expense
  const deleteMonthlyExpense = async (id) => {
    try {
      const headers = getAuthHeader();
      await axios.delete(`${API_URL}/monthly-expenses/${id}`, { headers });
      setMonthlyExpenses(monthlyExpenses.filter(exp => exp.id !== id));
      fetchData();
    } catch (error) {
      console.error('Error deleting monthly expense:', error);
      alert('Failed to delete expense');
    }
  };

  // Update monthly expense
  const updateMonthlyExpense = async (id, expense) => {
    try {
      const headers = getAuthHeader();
      const response = await axios.put(`${API_URL}/monthly-expenses/${id}`, expense, { headers });
      setMonthlyExpenses(monthlyExpenses.map(exp => exp.id === id ? response.data : exp));
      fetchData();
    } catch (error) {
      console.error('Error updating monthly expense:', error);
      alert('Failed to update expense');
    }
  };

  // Add transaction
  const addTransaction = async (transaction) => {
    try {
      const headers = getAuthHeader();
      if (transaction.isUpdate && transaction.id) {
        // Update existing transaction
        const response = await axios.put(`${API_URL}/transactions/${transaction.id}`, {
          description: transaction.description,
          amount: transaction.amount,
          transaction_date: transaction.transaction_date,
          category: transaction.category
        }, { headers });
        setTransactions(transactions.map(t => t.id === transaction.id ? response.data : t));
      } else {
        // Add new transaction
        const response = await axios.post(`${API_URL}/transactions`, transaction, { headers });
        setTransactions([response.data, ...transactions]);
      }
      fetchData();
    } catch (error) {
      console.error('Error adding/updating transaction:', error);
      alert('Failed to add/update transaction');
      throw error;
    }
  };

  // Delete transaction
  const deleteTransaction = async (id) => {
    try {
      const headers = getAuthHeader();
      await axios.delete(`${API_URL}/transactions/${id}`, { headers });
      setTransactions(transactions.filter(trans => trans.id !== id));
      fetchData();
    } catch (error) {
      console.error('Error deleting transaction:', error);
      alert('Failed to delete transaction');
    }
  };

  if (authLoading) {
    return (
      <div className="App">
        <div className="header">
          <h1>Loading...</h1>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return showRegister ? (
      <Register onSwitchToLogin={() => setShowRegister(false)} />
    ) : (
      <Login onSwitchToRegister={() => setShowRegister(true)} />
    );
  }

  if (loading) {
    return (
      <div className="App">
        <div className="header">
          <h1>Loading...</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="App professional-dashboard">
      {/* Top Navigation Bar */}
      <div className="top-navbar">
        <div className="navbar-brand">
          <span className="brand-icon">💰</span>
          <span className="brand-name">Expense Planner</span>
        </div>
        
        <div className="navbar-tabs">
          <button 
            className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <span className="tab-icon">📊</span>
            <span>Dashboard</span>
          </button>
          <button 
            className={`tab-btn ${activeTab === 'transactions' ? 'active' : ''}`}
            onClick={() => setActiveTab('transactions')}
          >
            <span className="tab-icon">💳</span>
            <span>Transactions</span>
          </button>
          <button 
            className={`tab-btn ${activeTab === 'reports' ? 'active' : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            <span className="tab-icon">📈</span>
            <span>Reports</span>
          </button>
          <button 
            className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <span className="tab-icon">⚙️</span>
            <span>Settings</span>
          </button>
        </div>

        <div className="navbar-user">
          <div className="user-avatar">{user?.username?.[0]?.toUpperCase()}</div>
          <span className="user-name">{user?.username}</span>
          <button onClick={logout} className="logout-btn">
            <span>🚪</span> Logout
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="main-content">
        {activeTab === 'dashboard' && (
          <div className="tab-content fade-in">
            <div className="content-header">
              <div>
                <h1>Dashboard Overview</h1>
                <p className="content-subtitle">Track your financial health at a glance</p>
              </div>
            </div>
            
            <div className="charts-grid">
              <MonthlyProjection
                salary={salary}
                openingBalance={openingBalance}
                planStartDate={planStartDate}
                salaryChanges={salaryChanges}
                additionalIncomes={additionalIncomes}
                monthlyExpenses={monthlyExpenses}
                transactions={transactions}
                currency={currency}
              />
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="tab-content fade-in">
            <div className="content-header">
              <div>
                <h1>Transactions Manager</h1>
                <p className="content-subtitle">Manage your income and expenses</p>
              </div>
            </div>
            
            {/* Sub-tabs for transaction sections */}
            <div className="sub-tabs">
              <button
                className={`sub-tab-btn ${transactionSubTab === 'income' ? 'active income-tab' : ''}`}
                onClick={() => setTransactionSubTab('income')}
              >
                <span className="tab-emoji">💵</span>
                <span>Additional Income Sources</span>
              </button>
              
              <button
                className={`sub-tab-btn ${transactionSubTab === 'expenses' ? 'active expenses-tab' : ''}`}
                onClick={() => setTransactionSubTab('expenses')}
              >
                <span className="tab-emoji">📝</span>
                <span>Monthly Recurring Expenses</span>
              </button>
              
              <button
                className={`sub-tab-btn ${transactionSubTab === 'daily' ? 'active daily-tab' : ''}`}
                onClick={() => setTransactionSubTab('daily')}
              >
                <span className="tab-emoji">💳</span>
                <span>Daily Transactions</span>
              </button>
            </div>
            
            {/* Tab Content */}
            <div className="transaction-sub-content">
              {transactionSubTab === 'income' && (
                <div className="fade-in">
                  <AdditionalIncome 
                    incomes={additionalIncomes}
                    onAdd={addAdditionalIncome}
                    onDelete={deleteAdditionalIncome}
                  />
                </div>
              )}
              
              {transactionSubTab === 'expenses' && (
                <div className="fade-in">
                  <MonthlyExpenses 
                    expenses={monthlyExpenses} 
                    onAdd={addMonthlyExpense}
                    onUpdate={updateMonthlyExpense}
                    onDelete={deleteMonthlyExpense}
                    categories={categories}
                    currency={currency}
                  />
                </div>
              )}
              
              {transactionSubTab === 'daily' && (
                <div className="fade-in">
                  <DailyTransactions 
                    transactions={transactions}
                    onAdd={addTransaction}
                    onDelete={deleteTransaction}
                    categories={categories}
                    currency={currency}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="tab-content fade-in">
            <div className="content-header">
              <div>
                <h1>Financial Reports</h1>
                <p className="content-subtitle">Analyze your spending patterns</p>
              </div>
            </div>
            
            <div className="charts-grid">
              <ExpenseChart 
                monthlyExpenses={monthlyExpenses}
                transactions={transactions}
                salary={salary}
                additionalIncomes={additionalIncomes}
                currency={currency}
                planStartDate={planStartDate}
              />
              
              <MonthlyExpenseReport
                monthlyExpenses={monthlyExpenses}
                transactions={transactions}
                salary={salary}
                salaryChanges={salaryChanges}
                currency={currency}
                salaryVisible={salaryVisible}
                toggleSalaryVisibility={() => setSalaryVisible(!salaryVisible)}
                openingBalance={openingBalance}
                planStartDate={planStartDate}
              />
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="tab-content fade-in">
            <Settings 
              salary={salary}
              openingBalance={openingBalance}
              planStartDate={planStartDate}
              onUpdateSettings={updateSettings}
              salaryChanges={salaryChanges}
              onAddSalaryChange={addSalaryChange}
              onDeleteSalaryChange={deleteSalaryChange}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
